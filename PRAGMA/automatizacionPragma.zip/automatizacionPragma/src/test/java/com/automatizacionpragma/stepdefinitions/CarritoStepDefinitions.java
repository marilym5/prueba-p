package com.automatizacionpragma.stepdefinitions;

import com.automatizacionpragma.tasks.AgregarCarrito;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.OnStage;

public class CarritoStepDefinitions {

    @Dado("que {actor} esta en la pagina de inicio de demoblaze")
    public void queMarilymEstaEnLaPaginaDeInicioDeDemoblaze(Actor actor) {
        actor.wasAbleTo(Open.url("https://www.demoblaze.com/index.html"));
    }
    @Cuando("^anade un producto al carrito (.*)")
    public void anadeUnProductoAlCarrito(String producto) {
        OnStage.theActorInTheSpotlight().attemptsTo(AgregarCarrito.elProducto(producto));
    }

}