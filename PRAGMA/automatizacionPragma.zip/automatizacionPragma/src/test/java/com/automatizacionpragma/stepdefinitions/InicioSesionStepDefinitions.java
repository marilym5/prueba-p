package com.automatizacionpragma.stepdefinitions;

import com.automatizacionpragma.questions.MensajeBienvenida;
import com.automatizacionpragma.tasks.IniciarSesion;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.OnStage;

import static com.automatizacionpragma.userinterface.HomePage.LOG_IN_LINK;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.containsStringIgnoringCase;


public class InicioSesionStepDefinitions {


    @Dado("que {actor} esta en la pagina de inicio de sesion de demoblaze")
    public void queActorEstaEnLaPaginaDeInicioDeSesionDeDemoblaze(Actor actor) {
        actor.wasAbleTo(Open.url("https://www.demoblaze.com/index.html"));
        actor.wasAbleTo(Click.on(LOG_IN_LINK));
    }

    @Cuando("se autentique en el sistema {word} {word}")
    public void seAutentiqueEnSistema(String usuario, String contrasenia) {
        OnStage.theActorInTheSpotlight().attemptsTo(IniciarSesion.conLasCredenciales(usuario, contrasenia));
    }

    @Entonces("deberia visualizar el mensaje de bienvenida")
    public void deberiaVisualizarElMensajeDeBienvenida() {
        OnStage.theActorInTheSpotlight().should(seeThat(MensajeBienvenida.text(), containsStringIgnoringCase("Welcome")));
    }
}