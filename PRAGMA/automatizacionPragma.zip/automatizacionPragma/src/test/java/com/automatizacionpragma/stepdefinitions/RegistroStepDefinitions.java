package com.automatizacionpragma.stepdefinitions;

import com.automatizacionpragma.questions.AlertQuestion;
import com.automatizacionpragma.tasks.Registrar;
import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.OnStage;

import static com.automatizacionpragma.userinterface.HomePage.SIGN_UP_LINK;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.equalTo;


public class RegistroStepDefinitions {
    @Dado("que {actor} esta en la pagina de registro de demoblaze")
    public void queActorEstaEnLaPaginaDeRegistroDeDemoblaze(Actor actor) {
        actor.wasAbleTo(Open.url("https://www.demoblaze.com/index.html"));
        actor.wasAbleTo(Click.on(SIGN_UP_LINK));
    }

    @Cuando("diligencie el formulario {word} {word}")
    public void diligencieElFormulario(String usuario, String contrasenia) {
        OnStage.theActorInTheSpotlight().attemptsTo(Registrar.conLosDatos(usuario, contrasenia));
    }

    @Entonces("^deberia visualizar el mensaje de la alerta (.*)")
    public void deberiaVisualizarLaAlerta(String mensaje) {
        OnStage.theActorInTheSpotlight().should(seeThat(AlertQuestion.text(), equalTo(mensaje)));
    }
}