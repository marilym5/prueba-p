package com.automatizacionpragma.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static com.automatizacionpragma.userinterface.InicioSesionPage.*;


public class IniciarSesion implements Task {
    private final String usuario;
    private final String contrasenia;

    public IniciarSesion(String usuario, String contrasenia) {
        this.usuario = usuario;
        this.contrasenia = contrasenia;
    }

    public static IniciarSesion conLasCredenciales(String usuario, String contrasenia) {
        return Tasks.instrumented(IniciarSesion.class, usuario, contrasenia);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Enter.theValue(usuario).into(USERNAME_INPUT),
                Enter.theValue(contrasenia).into(PASSWORD_INPUT),
                Click.on(LOG_IN_BUTTON)
        );
    }
}