package com.automatizacionpragma.userinterface;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;


public class RegistroPage {
    public static final Target USERNAME_INPUT = Target.the("campo usuario").
            located(By.id("sign-username"));
    public static final Target PASSWORD_INPUT = Target.the("campo contraseña").
            located(By.id("sign-password"));
    public static final Target SIGN_UP_BUTTON = Target.the("botón de registro").
            located(By.cssSelector("[onclick='register()']"));
}
