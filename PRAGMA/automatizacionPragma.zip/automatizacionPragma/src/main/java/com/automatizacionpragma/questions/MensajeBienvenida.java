package com.automatizacionpragma.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;
import net.serenitybdd.screenplay.waits.WaitUntil;

import static com.automatizacionpragma.userinterface.HomePage.WELCOME_LABEL;

public class MensajeBienvenida implements Question<String> {
    @Override
    public String answeredBy(Actor actor) {
        actor.attemptsTo(
                WaitUntil.the(WELCOME_LABEL, WebElementStateMatchers.isVisible())
                        .forNoMoreThan(15)
                        .seconds());
        return WELCOME_LABEL.resolveFor(actor).getText();
    }

    public static MensajeBienvenida text() {
        return new MensajeBienvenida();
    }
}