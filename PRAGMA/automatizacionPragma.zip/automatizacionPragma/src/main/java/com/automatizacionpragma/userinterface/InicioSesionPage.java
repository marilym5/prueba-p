package com.automatizacionpragma.userinterface;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;


public class InicioSesionPage {
    public static final Target USERNAME_INPUT = Target.the("campo usuario").
            located(By.id("loginusername"));
    public static final Target PASSWORD_INPUT = Target.the("campo contraseña").
            located(By.id("loginpassword"));
    public static final Target LOG_IN_BUTTON = Target.the("botón de inicio de sesión").
            located(By.cssSelector("[onclick='logIn()']"));
}
