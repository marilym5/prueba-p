package com.automatizacionpragma.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;

import static com.automatizacionpragma.userinterface.CarritoPage.CART_BUTTON;
import static com.automatizacionpragma.userinterface.CarritoPage.PRODUCT;


public class AgregarCarrito implements Task {
    private final String producto;


    public AgregarCarrito(String producto) {
        this.producto = producto;
    }

    public static AgregarCarrito elProducto(String producto) {
        return Tasks.instrumented(AgregarCarrito.class, producto);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Click.on(PRODUCT(producto)),
                Click.on(CART_BUTTON)
        );
    }
}