package com.automatizacionpragma.userinterface;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class CarritoPage {

    public static Target PRODUCT(String producto) {
        return Target.the("producto").
                located(By.xpath("//a[.='"+producto+"']"));
    }

    public static final Target CART_BUTTON = Target.the("Boton para agreagr al carrito").
            located(By.cssSelector(".btn-success"));
}
