package com.automatizacionpragma.tasks;

import com.automatizacionpragma.userinterface.InicioSesionPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;

import static com.automatizacionpragma.userinterface.RegistroPage.*;


public class Registrar implements Task {
    private final String usuario;
    private final String contrasenia;

    public Registrar(String usuario, String contrasenia) {
        this.usuario = usuario;
        this.contrasenia = contrasenia;
    }

    public static Registrar conLosDatos(String usuario, String contrasenia) {
        return Tasks.instrumented(Registrar.class, usuario, contrasenia);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Enter.theValue(usuario).into(USERNAME_INPUT),
                Enter.theValue(contrasenia).into(PASSWORD_INPUT),
                Click.on(SIGN_UP_BUTTON)
        );

    }
}