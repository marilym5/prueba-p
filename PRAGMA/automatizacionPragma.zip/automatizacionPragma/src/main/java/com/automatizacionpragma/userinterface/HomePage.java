package com.automatizacionpragma.userinterface;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;


public class HomePage {
    public static final Target LOG_IN_LINK = Target.the("enlace para ir al formulario de inicio de sesión").
            located(By.id("login2"));
    public static final Target SIGN_UP_LINK = Target.the("enlace para ir al formulario de registro de nuevo usuario").
            located(By.id("signin2"));
    public static final Target WELCOME_LABEL = Target.the("mensaje de bienvenida").
            located(By.id("nameofuser"));
}
